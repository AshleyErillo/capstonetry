const notificationBtn = document.getElementById('notificationBtn');
const notificationModal = document.getElementById('notificationModal');

notificationBtn.addEventListener('click', () => {
  notificationModal.style.display = notificationModal.style.display === 'block' ? 'none' : 'block';
});

window.addEventListener('click', (e) => {
  if (!notificationBtn.contains(e.target) && !notificationModal.contains(e.target)) {
    notificationModal.style.display = 'none';
  }
});

// Filter toggle logic
const filterAll = document.getElementById('filterAll');
const filterUnread = document.getElementById('filterUnread');

filterAll.addEventListener('click', () => {
  filterAll.classList.add('active');
  filterUnread.classList.remove('active');
  
  document.querySelectorAll('.notification-container').forEach((el) => {
    el.style.display = 'flex';
  });
});

filterUnread.addEventListener('click', () => {
  filterUnread.classList.add('active');
  filterAll.classList.remove('active');
  
  document.querySelectorAll('.notification-container').forEach((el) => {
    el.style.display = el.classList.contains('unread') ? 'flex' : 'none';
  });
});

// Mark notification as read
function markAsRead(button) {
  const container = button.closest('.notification-container');
  container.classList.remove('unread');
}